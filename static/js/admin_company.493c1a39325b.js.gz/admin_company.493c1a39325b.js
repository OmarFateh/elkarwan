// add placeholder to search bar
window.onload = function() {
    document.getElementById("searchbar").placeholder = "search by name";
};
